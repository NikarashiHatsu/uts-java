// Aghits Nidallah - 190511038
class Lahan {
    String jenis_lahan = "Lahan garapan";

    public void tampil_jenis_lahan() {
        System.out.println("Jenis lahan adalah: " + jenis_lahan);
    }
}